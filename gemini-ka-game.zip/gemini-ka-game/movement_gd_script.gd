extends CharacterBody3D

const SPEED = 5.0
const JUMP_VELOCITY = 4.5
const ROTATION_SPEED = 2.0  # Camera ghumne ki speed

var gravity = ProjectSettings.get_setting("physics/3d/default_gravity")

# Nodes check
@onready var neck := $Neck
@onready var camera := $Neck/Camera3D

func _physics_process(delta: float) -> void:
	# 1. Gravity (Niche girna)
	if not is_on_floor():
		velocity.y -= gravity * delta

	# 2. Jump (Space Bar)
	if Input.is_key_pressed(KEY_SPACE) and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# 3. CAMERA ROTATION (Arrow Keys)
	# Left/Right se pura body ghumege
	if Input.is_key_pressed(KEY_A):
		rotate_y(ROTATION_SPEED * delta)
	if Input.is_key_pressed(KEY_D):
		rotate_y(-ROTATION_SPEED * delta)
	
	# Up/Down se sirf gardan (Neck) upar-niche hogi
	if Input.is_key_pressed(KEY_W):
		neck.rotate_x(ROTATION_SPEED * delta)
	if Input.is_key_pressed(KEY_S):
		neck.rotate_x(-ROTATION_SPEED * delta)
	
	# Gardan zyada na mude (Limit 80 degree)
	neck.rotation.x = clamp(neck.rotation.x, deg_to_rad(-80), deg_to_rad(80))

	# 4. MOVEMENT (W, A, S, D) - Fixed Directions
	var direction = Vector3.ZERO
	var basis = global_transform.basis
	
	if Input.is_key_pressed(KEY_W):
		direction -= basis.z  # Aage
	if Input.is_key_pressed(KEY_S):
		direction += basis.z  # Piche
	if Input.is_key_pressed(KEY_A):
		direction -= basis.x  # Left
	if Input.is_key_pressed(KEY_D):
		direction += basis.x  # Right

	direction = direction.normalized()

	if direction:
		velocity.x = direction.x * SPEED
		velocity.z = direction.z * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		velocity.z = move_toward(velocity.z, 0, SPEED)

	move_and_slide()
