extends CharacterBody3D

const SPEED = 5.0
const JUMP_VELOCITY = 4.5

@onready var neck = $Neck
@onready var camera = $Neck/MainCamera

func _physics_process(delta: float) -> void:
	# Gravity
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Jump
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Movement
	var input_dir := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	
	if direction:
		velocity.x = direction.x * SPEED
		velocity.z = direction.z * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED * delta * 5)
		velocity.z = move_toward(velocity.z, 0, SPEED * delta * 5)

	move_and_slide()

	# Player rotate (Left/Right)
	if Input.is_key_pressed(KEY_LEFT):
		rotate_y(deg_to_rad(120 * delta))
	if Input.is_key_pressed(KEY_RIGHT):
		rotate_y(deg_to_rad(-120 * delta))

	# Camera rotate (Up/Down)
	if Input.is_key_pressed(KEY_UP):
		neck.rotate_x(deg_to_rad(120 * delta))
	if Input.is_key_pressed(KEY_DOWN):
		neck.rotate_x(deg_to_rad(-120 * delta))

	# Clamp camera
	neck.rotation.x = clamp(neck.rotation.x, deg_to_rad(-90), deg_to_rad(90))
